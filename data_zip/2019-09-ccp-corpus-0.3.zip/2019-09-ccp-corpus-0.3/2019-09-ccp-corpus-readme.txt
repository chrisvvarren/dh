====================================================
About the Colored Conventions Corpus
====================================================
This corpus contains transcriptions of the minutes, proceedings, and primary sources of the Colored Conventions movement. 

The transcripts are the results of great dedication and care by the volunteers on the Transcribe Minutes initiative (coloredconventions.org/transcribe-minutes). Special thanks and recognition are due to the National Lay of the African Methodist Church, with whose partnership much of this work is being accomplished. 

Please visit our site to learn more about the Colored Conventions (coloredconventions.org)

==========================
What is the CCP Corpus?
==========================

The CCP Corpus provides bulk access to our growing collection of transcribed records of the Colored Conventions. 

The Colored Conventions Project seeks to bring the buried history of nineteenth-century Black organizing to digital life. Part of this work is enabling researchers to look for patterns across this broad, rich history in the language of the primary sources themselves. These transcriptions are made possible by the dedicated volunteers of the CCP Transcribe Minutes initiative (coloredconventions.org/transcribe-minutes). 

The CCP Corpus is designed to be easy to use in most text-analysis applications, from Voyant Tools (voyant-tools.org) to topic modeling, the Natural Language Toolkit, or natural language processing. 

Update history
Version 0.3; Sept. 2019
Version 0.2; Nov. 2016
Version 0.1; Nov. 2015

==========================
Terms & Conditions
==========================

The act of downloading and using the CCP Corpus expresses a commitment to the following principles: 

I honor CCP’s commitment to a use of data that humanizes and acknowledges the Black people whose collective organizational histories are assembled here. Although the subjects of datasets are often reduced to abstract data points, I will contextualize and narrate the conditions of the people who appear as “data” and to name them when possible.

I will include the above language in my first citation of any data I pull/use from the CCP Corpus.

I will be sensitive to a standard use of language that again reduces 19th-century Black people to being objects. Words like "item" and "object,” standard in digital humanities and data collection, fall into this category.

I will acknowledge that Colored Conventions were produced through collectives rather than by the work of singular figures or events.

I will fully attribute the Colored Conventions Project for corpora content.

==========================
How do I use it?
==========================

Click on the download link to start downloading the zipped folder with all of the CCP Corpus. 

As the CCP remains committed to the large-scale recovery of the convention minutes, please be aware that this collection is as yet incomplete. All uses of these materials published online or in print should indicate the provisional nature of the CCP Corpus. The CCP Corpus will grow significantly with the progress of Transcribe Minutes and its successors. Each updated version will be titled with the year and month last updated (i.e. CCP-Corpus-2015-11.zip). 

The downloaded zip file includes: 

+A folder with all of the minutes in plain-text format

+A table of contents in CSV form with all relevant event and bibliographic data for each of the documents. 

+A text file named "Read Me" with notes about updates, permissions and citation guidelines.  

==========================
Metadata Glossary
==========================

The table of contents CSV file provides metadata to describe each of the texts in the collection. 

docID - a unique identifier for each convention document

eventID	- a unique identifier for each convention event

Convention_Type - the category of conventions (controlled vocabulary)

docTitle - if any, the title of the document

City - the city where the convention event was held

State - the state where the convention event was held

Country - the country where the convention event was held

Item_Number - the unique item on the CCP website

URL - a hyperlink to the document on the CCP website 


==========================
Feedback
==========================
We are eager to promote innovative uses of the convention minutes. If you are using these materials, or have any feedback to improve the CCP Corpus, please contact us at coloredconventions@udel.edu. 

==========================
Copyright Statement
==========================

The Colored Conventions Project Corpus is being released under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. 

https://creativecommons.org/licenses/by-nc-sa/4.0/

====================================================
About the Colored Conventions Project
====================================================

From 1830 until the 1890s, already free and once captive Black people came together in state and national political meetings called "Colored Conventions." Before the War, they strategized about how to achieve educational, labor and legal justice at a moment when Black rights were constricting nationally and locally. After the War, their numbers swelled as they continued to mobilize to ensure that Black citizenship rights and safety, Black labor rights and land, Black education and institutions would be protected under the law.

The delegates to these meetings included the most well-known, if mostly male, writers, organizers, church leaders, newspaper editors, and entrepreneurs in the canon of early African-American leadership—and thousands whose names and histories have long been forgotten. What is left of this phenomenal effort are rare proceedings, newspaper coverage, and petitions that have never before been collected in one place.
This project seeks to not only learn about the lives of male delegates, the places where they met and the social networks that they created, but also to account for the crucial work done by Black women in the broader social networks that made these conventions possible.

ColoredConventions.org endeavors to transform teaching and learning about this historic collective organizing effort—and about the many leaders and places involved in it—bringing them to digital life for a new generation of students and scholars across disciplines and for community researchers interested in the history of activist church, civil rights, educational and entrepreneurial engagement.